package com.example.androidvinted.model;

import com.example.androidvinted.contract.LoginContract;
import com.example.androidvinted.model.pojo.User;

public class LoginModel implements LoginContract.Model {
    @Override
    public void findUserWS(User user, OnLoginUserListener onLoginUserListener) {

    }
}
