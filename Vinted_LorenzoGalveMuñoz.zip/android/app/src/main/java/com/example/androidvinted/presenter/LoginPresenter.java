package com.example.androidvinted.presenter;

import com.example.androidvinted.contract.LoginContract;
import com.example.androidvinted.model.pojo.Products;
import com.example.androidvinted.model.pojo.User;

public class LoginPresenter implements LoginContract.Presenter {
    @Override
    public void login(User user) {

    }
    @Override
    public void lstProducts(Products products) {

    }
    //public void lstFilms(){}
}
